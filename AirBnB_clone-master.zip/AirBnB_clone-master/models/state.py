#!/usr/bin/python3
"""This module contains one class State"""
from models.base_model import BaseModel


class State(BaseModel):
    """child class of the class Basemodel"""
    name = ""
