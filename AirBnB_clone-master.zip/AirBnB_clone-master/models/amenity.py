#!/usr/bin/python3
"""This module contains one class Amenity"""
from models.base_model import BaseModel


class Amenity(BaseModel):
    """child class of the class BaseModel"""
    name = ""
